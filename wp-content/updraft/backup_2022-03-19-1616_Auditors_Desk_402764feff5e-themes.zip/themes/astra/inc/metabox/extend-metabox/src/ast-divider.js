/**
 * Divider component.
 */
const Divider = () => (
	<div className='ast-meta-settings-divider' />
)

export default Divider
