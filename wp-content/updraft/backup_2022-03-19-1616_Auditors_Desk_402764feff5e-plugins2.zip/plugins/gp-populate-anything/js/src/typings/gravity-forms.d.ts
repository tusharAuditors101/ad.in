interface GravityFormsField {
	inputs: any
	choices: any
	id: string
	type: string
	inputType: string
}
