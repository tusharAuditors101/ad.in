<?php
/**
 * Template for quiz close tag
 *
 * @package WPQuiz
 *
 * @var \WPQuiz\Quiz $quiz Quiz object.
 */

?>
</div>
<!-- // wp quiz-->
